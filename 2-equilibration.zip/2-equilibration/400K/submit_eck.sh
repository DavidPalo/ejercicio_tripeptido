#!/bin/bash
#
#SBATCH -p eck-q
#SBATCH --chdir=/home/alumno16/MM/ejercicio_tripeptido/2-equilibration/400K
#SBATCH -J equilibrado
#SBATCH --cpus-per-task=1

date
gmx mdrun -deffnm aqa -c aqa.g96 -nt 1
date



